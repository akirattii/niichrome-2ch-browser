# niichrome 2ch browser

**niichrome 2ch browser** is highly functional 2ch.net browser for Chrome and Chrome OS. 

You can install it at [Chrome Web Store](https://chrome.google.com/webstore/detail/niichrome-2ch%E3%83%96%E3%83%A9%E3%82%A6%E3%82%B6/iabgdknpefinjdmfacfgkpfiiglbdhnc).
